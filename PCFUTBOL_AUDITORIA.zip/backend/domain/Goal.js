import { Player } from "./Player.js";

export class Goal {
  constructor (player, minute) {
    this.player = player;
    this.minute = minute;
  }
}

const newPlayer = new Player("Ronaldo", 18);

const anotherPlayer = new Player("Ronaldo", 18);
// console.log(newPlayer);

const goal1 = new Goal(newPlayer, 23);
const goal2 = new Goal(newPlayer, 76);
const goal3 = new Goal(anotherPlayer, 53);
console.log(goal1);
console.log(goal2);


console.log(`${goal1.player.name}, min ${goal1.minute}`);
console.log(`${goal2.player.name}, min ${goal2.minute}`);

console.log(goal1.player === goal2.player);
console.log(goal1 === goal3.player);

