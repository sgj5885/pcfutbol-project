import { Goal } from "./Goal.js";

export class Match {
  #goals;
  constructor(homeTeam, awayTeam) {
    this.homeTeam = homeTeam;
    this.awayTeam = awayTeam;
    this.#goals = [];
    this.cards = [];
    this.injuries = [];
  }

  get goalsMatch() {
    return this.#goals.slice();  //Devuelve un array de todos los goles que se marcan en un partido
  }

  get score() {
    return this.goalsMatch.length;
  }

  registerGoal(goal) {
   return this.#goals.push(goal);
  }
}

const firstMatch = new Match ("R. Madrid", "F.C. Barcelona")

console.log(firstMatch);
console.log(firstMatch.goalsMatch);

const oneGoal = new Goal('Player', 23)
console.log(oneGoal);
console.log(firstMatch.goalsMatch);



console.log(firstMatch.registerGoal(oneGoal));


// console.log(firstMatch);

const newGoal = new Goal('Player2', 38);

console.log(firstMatch.registerGoal(newGoal));

console.log(firstMatch.goalsMatch);
console.log(firstMatch.score);

